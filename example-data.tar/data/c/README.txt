README Lines for very short tests.
