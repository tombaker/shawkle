README 01  One possible configuration for running this demo (customize for your own system):
README 02       apple.py           - Must be in your path and executable.
README 03       data               - Install this directory somewhere -- eg, ~/agit/apple/data
README 04       README.txt         - This file, which is located at ~/agit/apple/data/a/README.txt.
README 05   Before running the demo, edit:
README 06       ./.files2dirs      - Configure .files2dirs by replacing ~/agit/apple/data with the location of your data directories.
README 07   Before running the demo, use your favorite editor to inspect:
README 08       ./.globalrules     - Rules which, by default, are run first.
README 09       ./.rules           - Rules which, by default, are run second.
README 10       ./.sedtxt          - Stream edits to convert text files before they are urlified (turned into HTML).
README 11       ./.sedhtml         - Stream edits to make the HTML files look pretty (e.g., shortening pathnames or URLs).
README 12   To run the demo:
README 13       cd ~/agit/apple/data/a
README 14       Run: apple.py --files2dirs  "~/agit/apple/data/a/.files2dirs"   \
README 15                     --globalrules "~/agit/apple/data/a/.globalrules"  \
README 16                     --sedtxt      "~/agit/apple/data/a/.sedtxt"       \
README 17                     --sedhtml     "~/agit/apple/data/a/.sedhtml"
README 18   After execution, compare the files in:
README 19        ~/agit/apple/data/a
README 20        ~/agit/apple/data/a/.backup
README 21   Then
README 22        cd ~/agit/apple/data/b
README 23        Run apple as above. Inspect results.
README 24   Then
README 25        cd ~/agit/apple/data/a
README 26        edit calendar.txt, changing the equals sign ('=') at the beginning of each line to ('B')
README 27        Run apple again, 
README 28        cd ~/agit/apple/data/b
README 29        Run apple again. Inspect results.
README 30   To start the demo over again with fresh data, delete the directory and un-pack example-data.tar.
